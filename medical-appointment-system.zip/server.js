const express = require("express")
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")
const cookieParser = require("cookie-parser")
const path = require("path")
const cors = require("cors")
const compression = require("compression")
const { MongoClient, ObjectId } = require("mongodb")
require("dotenv").config()

const app = express()
const PORT = process.env.PORT || 3000
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-in-production"

// MongoDB connection
let db
const connectDB = async () => {
  try {
    const client = new MongoClient(process.env.MONGODB_URI)
    await client.connect()
    db = client.db("medical_booking")
    console.log("✅ Connected to MongoDB")

    // Create indexes
    await createIndexes()
    await seedDatabase()
  } catch (error) {
    console.error("❌ MongoDB connection failed:", error)
    process.exit(1)
  }
}

// Create database indexes
const createIndexes = async () => {
  try {
    // Users collection indexes
    await db.collection("users").createIndex({ email: 1 }, { unique: true })
    await db.collection("users").createIndex({ role: 1 })

    // Doctors collection indexes
    await db.collection("doctors").createIndex({ email: 1 }, { unique: true })
    await db.collection("doctors").createIndex({ specialization: 1 })

    // Appointments collection indexes
    await db.collection("appointments").createIndex({ patientId: 1 })
    await db.collection("appointments").createIndex({ doctorId: 1 })
    await db.collection("appointments").createIndex({ appointmentDate: 1 })
    await db.collection("appointments").createIndex({ status: 1 })
    await db
      .collection("appointments")
      .createIndex(
        { doctorId: 1, appointmentDate: 1, appointmentTime: 1 },
        { unique: true, partialFilterExpression: { status: { $ne: "cancelled" } } },
      )

    console.log("✅ Database indexes created")
  } catch (error) {
    console.log("ℹ️ Indexes might already exist")
  }
}

// Seed database with sample doctors
const seedDatabase = async () => {
  try {
    const doctorCount = await db.collection("doctors").countDocuments()
    if (doctorCount === 0) {
      console.log("👨‍⚕️ Seeding doctors data...")

      const doctors = [
        {
          name: "John Smith",
          specialization: "Cardiology",
          email: "john.smith@hospital.com",
          phone: "123-456-7890",
          availableDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
          availableHours: "09:00-17:00",
          consultationFee: 150.0,
          experienceYears: 15,
          qualification: "MD, FACC - Harvard Medical School",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: "Sarah Johnson",
          specialization: "Dermatology",
          email: "sarah.johnson@hospital.com",
          phone: "123-456-7891",
          availableDays: ["Monday", "Wednesday", "Friday"],
          availableHours: "10:00-16:00",
          consultationFee: 120.0,
          experienceYears: 12,
          qualification: "MD, Dermatology - Johns Hopkins University",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: "Michael Brown",
          specialization: "Orthopedics",
          email: "michael.brown@hospital.com",
          phone: "123-456-7892",
          availableDays: ["Tuesday", "Thursday", "Saturday"],
          availableHours: "08:00-14:00",
          consultationFee: 180.0,
          experienceYears: 18,
          qualification: "MD, Orthopedic Surgery - Mayo Clinic",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: "Emily Davis",
          specialization: "Pediatrics",
          email: "emily.davis@hospital.com",
          phone: "123-456-7893",
          availableDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
          availableHours: "09:00-17:00",
          consultationFee: 100.0,
          experienceYears: 10,
          qualification: "MD, Pediatrics - Stanford University",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: "Robert Wilson",
          specialization: "Neurology",
          email: "robert.wilson@hospital.com",
          phone: "123-456-7894",
          availableDays: ["Monday", "Wednesday", "Friday"],
          availableHours: "11:00-18:00",
          consultationFee: 200.0,
          experienceYears: 20,
          qualification: "MD, PhD, Neurology - UCLA Medical Center",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: "Lisa Anderson",
          specialization: "Gynecology",
          email: "lisa.anderson@hospital.com",
          phone: "123-456-7895",
          availableDays: ["Tuesday", "Thursday", "Friday"],
          availableHours: "09:00-15:00",
          consultationFee: 140.0,
          experienceYears: 14,
          qualification: "MD, OB/GYN - Columbia University",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: "David Martinez",
          specialization: "Psychiatry",
          email: "david.martinez@hospital.com",
          phone: "123-456-7896",
          availableDays: ["Monday", "Tuesday", "Wednesday", "Thursday"],
          availableHours: "10:00-18:00",
          consultationFee: 160.0,
          experienceYears: 16,
          qualification: "MD, Psychiatry - Yale School of Medicine",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: "Jennifer Lee",
          specialization: "Ophthalmology",
          email: "jennifer.lee@hospital.com",
          phone: "123-456-7897",
          availableDays: ["Monday", "Wednesday", "Friday", "Saturday"],
          availableHours: "08:00-16:00",
          consultationFee: 130.0,
          experienceYears: 11,
          qualification: "MD, Ophthalmology - University of Pennsylvania",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ]

      await db.collection("doctors").insertMany(doctors)
      console.log("✅ Doctors data seeded successfully")
    }
  } catch (error) {
    console.error("Error seeding database:", error)
  }
}

// Middleware
app.use(compression())
app.use(
  cors({
    origin: process.env.CORS_ORIGIN || "*",
    credentials: true,
  }),
)
app.use(express.json({ limit: "10mb" }))
app.use(express.urlencoded({ extended: true, limit: "10mb" }))
app.use(cookieParser())
app.use(express.static("public"))

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const token = req.cookies.token

  if (!token) {
    return res.status(401).json({ error: "Access denied" })
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET)
    req.user = decoded
    next()
  } catch (error) {
    res.status(400).json({ error: "Invalid token" })
  }
}

// Health check endpoint
app.get("/health", (req, res) => {
  res.status(200).json({
    status: "OK",
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    database: db ? "connected" : "disconnected",
  })
})

// Serve HTML pages
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"))
})

app.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "login.html"))
})

app.get("/register", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "register.html"))
})

app.get("/dashboard", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "dashboard.html"))
})

app.get("/book-appointment", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "book-appointment.html"))
})

app.get("/appointments", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "appointments.html"))
})

// API Routes

// Register
app.post("/api/register", async (req, res) => {
  try {
    const { name, email, password, phone, role } = req.body

    // Basic validation
    if (!name || !email || !password) {
      return res.status(400).json({ error: "Name, email, and password are required" })
    }

    if (password.length < 8) {
      return res.status(400).json({ error: "Password must be at least 8 characters long" })
    }

    // Check if user exists
    const existingUser = await db.collection("users").findOne({ email: email.toLowerCase() })
    if (existingUser) {
      return res.status(400).json({ error: "User already exists" })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12)

    // Create user
    const userData = {
      name: name.trim(),
      email: email.toLowerCase().trim(),
      password: hashedPassword,
      phone: phone?.trim(),
      role: role || "patient",
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const result = await db.collection("users").insertOne(userData)

    res.status(201).json({
      message: "User registered successfully",
      userId: result.insertedId,
    })
  } catch (error) {
    console.error("Registration error:", error)
    res.status(500).json({ error: "Registration failed" })
  }
})

// Login
app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required" })
    }

    // Find user
    const user = await db.collection("users").findOne({ email: email.toLowerCase() })
    if (!user) {
      return res.status(401).json({ error: "Invalid credentials" })
    }

    // Verify password
    const validPassword = await bcrypt.compare(password, user.password)
    if (!validPassword) {
      return res.status(401).json({ error: "Invalid credentials" })
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: user._id.toString(),
        email: user.email,
        role: user.role,
      },
      JWT_SECRET,
      { expiresIn: "24h" },
    )

    // Set HTTP-only cookie
    res.cookie("token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    })

    res.status(200).json({
      message: "Login successful",
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    })
  } catch (error) {
    console.error("Login error:", error)
    res.status(500).json({ error: "Login failed" })
  }
})

// Get doctors
app.get("/api/doctors", async (req, res) => {
  try {
    const doctors = await db
      .collection("doctors")
      .find({})
      .sort({ name: 1 })
      .project({
        name: 1,
        specialization: 1,
        availableDays: 1,
        availableHours: 1,
        consultationFee: 1,
        experienceYears: 1,
        qualification: 1,
      })
      .toArray()

    res.status(200).json(doctors)
  } catch (error) {
    console.error("Database error:", error)
    res.status(500).json({ error: "Failed to fetch doctors" })
  }
})

// Get user appointments
app.get("/api/appointments", authenticateToken, async (req, res) => {
  try {
    const { status, limit = 50, offset = 0 } = req.query
    const matchStage = { patientId: new ObjectId(req.user.userId) }

    if (status && status !== "all") {
      matchStage.status = status
    }

    const appointments = await db
      .collection("appointments")
      .aggregate([
        { $match: matchStage },
        {
          $lookup: {
            from: "doctors",
            localField: "doctorId",
            foreignField: "_id",
            as: "doctor",
          },
        },
        { $unwind: "$doctor" },
        {
          $project: {
            appointmentDate: 1,
            appointmentTime: 1,
            status: 1,
            symptoms: 1,
            diagnosis: 1,
            prescription: 1,
            notes: 1,
            createdAt: 1,
            "doctor.name": 1,
            "doctor.specialization": 1,
            "doctor.consultationFee": 1,
          },
        },
        { $sort: { appointmentDate: -1, appointmentTime: -1 } },
        { $skip: Number.parseInt(offset) },
        { $limit: Number.parseInt(limit) },
      ])
      .toArray()

    // Format the response to match frontend expectations
    const formattedAppointments = appointments.map((apt) => ({
      id: apt._id,
      appointment_date: apt.appointmentDate,
      appointment_time: apt.appointmentTime,
      status: apt.status,
      symptoms: apt.symptoms,
      diagnosis: apt.diagnosis,
      prescription: apt.prescription,
      notes: apt.notes,
      created_at: apt.createdAt,
      doctor_name: apt.doctor.name,
      specialization: apt.doctor.specialization,
      consultation_fee: apt.doctor.consultationFee,
    }))

    res.status(200).json(formattedAppointments)
  } catch (error) {
    console.error("Database error:", error)
    res.status(500).json({ error: "Database operation failed" })
  }
})

// Book appointment
app.post("/api/appointments", authenticateToken, async (req, res) => {
  try {
    const { doctor_id, appointment_date, appointment_time, symptoms } = req.body

    if (!doctor_id || !appointment_date || !appointment_time || !symptoms) {
      return res.status(400).json({ error: "All fields are required" })
    }

    // Validate appointment date
    const appointmentDate = new Date(appointment_date)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    if (appointmentDate < today) {
      return res.status(400).json({ error: "Appointment date cannot be in the past" })
    }

    // Check if appointment slot is available
    const existing = await db.collection("appointments").findOne({
      doctorId: new ObjectId(doctor_id),
      appointmentDate: appointment_date,
      appointmentTime: appointment_time,
      status: { $ne: "cancelled" },
    })

    if (existing) {
      return res.status(400).json({ error: "This time slot is already booked" })
    }

    // Book the appointment
    const appointmentData = {
      patientId: new ObjectId(req.user.userId),
      doctorId: new ObjectId(doctor_id),
      appointmentDate: appointment_date,
      appointmentTime: appointment_time,
      symptoms: symptoms.trim(),
      status: "scheduled",
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const result = await db.collection("appointments").insertOne(appointmentData)

    res.status(201).json({
      message: "Appointment booked successfully",
      appointmentId: result.insertedId,
    })
  } catch (error) {
    console.error("Database error:", error)
    res.status(500).json({ error: "Database operation failed" })
  }
})

// Cancel appointment
app.patch("/api/appointments/:id/cancel", authenticateToken, async (req, res) => {
  try {
    const { id } = req.params

    const result = await db.collection("appointments").updateOne(
      {
        _id: new ObjectId(id),
        patientId: new ObjectId(req.user.userId),
        status: "scheduled",
      },
      {
        $set: {
          status: "cancelled",
          updatedAt: new Date(),
        },
      },
    )

    if (result.matchedCount === 0) {
      return res.status(404).json({ error: "Appointment not found or cannot be cancelled" })
    }

    res.status(200).json({ message: "Appointment cancelled successfully" })
  } catch (error) {
    console.error("Database error:", error)
    res.status(500).json({ error: "Failed to cancel appointment" })
  }
})

// Logout
app.post("/api/logout", (req, res) => {
  res.clearCookie("token")
  res.json({ message: "Logged out successfully" })
})

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).json({ error: "Something went wrong!" })
})

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: "Route not found" })
})

// Start server
const startServer = async () => {
  await connectDB()
  app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`)
    console.log(`🌐 Environment: ${process.env.NODE_ENV || "development"}`)
    console.log(`📱 Application URL: http://localhost:${PORT}`)
  })
}

startServer().catch(console.error)
