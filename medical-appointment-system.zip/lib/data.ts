// Sample data for the medical appointment system
export interface User {
  id: string
  name: string
  email: string
  password: string
  phone: string
  role: "patient" | "doctor" | "admin"
  createdAt: Date
}

export interface Doctor {
  id: string
  name: string
  specialization: string
  email: string
  phone: string
  availableDays: string[]
  availableHours: string
  consultationFee: number
  experienceYears: number
  qualification: string
  image?: string
}

export interface Appointment {
  id: string
  patientId: string
  doctorId: string
  appointmentDate: string
  appointmentTime: string
  status: "scheduled" | "completed" | "cancelled"
  symptoms: string
  diagnosis?: string
  prescription?: string
  notes?: string
  createdAt: Date
}

// Sample doctors data
export const sampleDoctors: Doctor[] = [
  {
    id: "1",
    name: "John Smith",
    specialization: "Cardiology",
    email: "john.smith@hospital.com",
    phone: "123-456-7890",
    availableDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    availableHours: "09:00-17:00",
    consultationFee: 150,
    experienceYears: 15,
    qualification: "MD, FACC - Harvard Medical School",
  },
  {
    id: "2",
    name: "Sarah Johnson",
    specialization: "Dermatology",
    email: "sarah.johnson@hospital.com",
    phone: "123-456-7891",
    availableDays: ["Monday", "Wednesday", "Friday"],
    availableHours: "10:00-16:00",
    consultationFee: 120,
    experienceYears: 12,
    qualification: "MD, Dermatology - Johns Hopkins University",
  },
  {
    id: "3",
    name: "Michael Brown",
    specialization: "Orthopedics",
    email: "michael.brown@hospital.com",
    phone: "123-456-7892",
    availableDays: ["Tuesday", "Thursday", "Saturday"],
    availableHours: "08:00-14:00",
    consultationFee: 180,
    experienceYears: 18,
    qualification: "MD, Orthopedic Surgery - Mayo Clinic",
  },
  {
    id: "4",
    name: "Emily Davis",
    specialization: "Pediatrics",
    email: "emily.davis@hospital.com",
    phone: "123-456-7893",
    availableDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    availableHours: "09:00-17:00",
    consultationFee: 100,
    experienceYears: 10,
    qualification: "MD, Pediatrics - Stanford University",
  },
  {
    id: "5",
    name: "Robert Wilson",
    specialization: "Neurology",
    email: "robert.wilson@hospital.com",
    phone: "123-456-7894",
    availableDays: ["Monday", "Wednesday", "Friday"],
    availableHours: "11:00-18:00",
    consultationFee: 200,
    experienceYears: 20,
    qualification: "MD, PhD, Neurology - UCLA Medical Center",
  },
  {
    id: "6",
    name: "Lisa Anderson",
    specialization: "Gynecology",
    email: "lisa.anderson@hospital.com",
    phone: "123-456-7895",
    availableDays: ["Tuesday", "Thursday", "Friday"],
    availableHours: "09:00-15:00",
    consultationFee: 140,
    experienceYears: 14,
    qualification: "MD, OB/GYN - Columbia University",
  },
  {
    id: "7",
    name: "David Martinez",
    specialization: "Psychiatry",
    email: "david.martinez@hospital.com",
    phone: "123-456-7896",
    availableDays: ["Monday", "Tuesday", "Wednesday", "Thursday"],
    availableHours: "10:00-18:00",
    consultationFee: 160,
    experienceYears: 16,
    qualification: "MD, Psychiatry - Yale School of Medicine",
  },
  {
    id: "8",
    name: "Jennifer Lee",
    specialization: "Ophthalmology",
    email: "jennifer.lee@hospital.com",
    phone: "123-456-7897",
    availableDays: ["Monday", "Wednesday", "Friday", "Saturday"],
    availableHours: "08:00-16:00",
    consultationFee: 130,
    experienceYears: 11,
    qualification: "MD, Ophthalmology - University of Pennsylvania",
  },
]

// In-memory storage (in a real app, this would be a database)
const users: User[] = []
const appointments: Appointment[] = []

// Utility functions
export const findUserByEmail = (email: string): User | undefined => {
  return users.find((user) => user.email.toLowerCase() === email.toLowerCase())
}

export const findUserById = (id: string): User | undefined => {
  return users.find((user) => user.id === id)
}

export const createUser = (userData: Omit<User, "id" | "createdAt">): User => {
  const newUser: User = {
    ...userData,
    id: Date.now().toString(),
    createdAt: new Date(),
  }
  users.push(newUser)
  return newUser
}

export const findDoctorById = (id: string): Doctor | undefined => {
  return sampleDoctors.find((doctor) => doctor.id === id)
}

export const createAppointment = (appointmentData: Omit<Appointment, "id" | "createdAt">): Appointment => {
  const newAppointment: Appointment = {
    ...appointmentData,
    id: Date.now().toString(),
    createdAt: new Date(),
  }
  appointments.push(newAppointment)
  return newAppointment
}

export const getAppointmentsByPatientId = (patientId: string): Appointment[] => {
  return appointments.filter((apt) => apt.patientId === patientId)
}

export const getAppointmentById = (id: string): Appointment | undefined => {
  return appointments.find((apt) => apt.id === id)
}

export const updateAppointmentStatus = (id: string, status: Appointment["status"]): boolean => {
  const appointment = appointments.find((apt) => apt.id === id)
  if (appointment) {
    appointment.status = status
    return true
  }
  return false
}

export const checkAppointmentAvailability = (doctorId: string, date: string, time: string): boolean => {
  return !appointments.some(
    (apt) =>
      apt.doctorId === doctorId &&
      apt.appointmentDate === date &&
      apt.appointmentTime === time &&
      apt.status !== "cancelled",
  )
}

// Time slots for appointments
export const timeSlots = [
  "09:00",
  "09:30",
  "10:00",
  "10:30",
  "11:00",
  "11:30",
  "14:00",
  "14:30",
  "15:00",
  "15:30",
  "16:00",
  "16:30",
]

// Utility functions for formatting
export const formatDate = (dateString: string): string => {
  return new Date(dateString).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })
}

export const formatTime = (timeString: string): string => {
  const [hours, minutes] = timeString.split(":")
  const hour = Number.parseInt(hours)
  const ampm = hour >= 12 ? "PM" : "AM"
  const displayHour = hour % 12 || 12
  return `${displayHour}:${minutes} ${ampm}`
}
