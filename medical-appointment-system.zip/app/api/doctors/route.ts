import { NextResponse } from "next/server"
import { sampleDoctors } from "@/lib/data"

export async function GET() {
  try {
    return NextResponse.json(sampleDoctors)
  } catch (error) {
    console.error("Database error:", error)
    return NextResponse.json({ error: "Failed to fetch doctors" }, { status: 500 })
  }
}
