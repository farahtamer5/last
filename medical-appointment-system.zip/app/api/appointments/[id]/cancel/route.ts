import { type NextRequest, NextResponse } from "next/server"
import { updateAppointmentStatus, getAppointmentById } from "@/lib/data"

// Helper function to get user from token
function getUserFromToken(request: NextRequest) {
  const token = request.cookies.get("medibook_token")?.value

  if (!token) return null

  if (token === "demo-token") {
    return { id: "demo-patient-1", email: "patient@demo.com", role: "patient" }
  }

  if (token.startsWith("user-")) {
    const userId = token.replace("user-", "")
    return { id: userId, email: "", role: "patient" }
  }

  return null
}

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = getUserFromToken(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const appointmentId = params.id
    const appointment = getAppointmentById(appointmentId)

    if (!appointment || appointment.patientId !== user.id) {
      return NextResponse.json({ error: "Appointment not found" }, { status: 404 })
    }

    if (appointment.status !== "scheduled") {
      return NextResponse.json({ error: "Cannot cancel this appointment" }, { status: 400 })
    }

    const success = updateAppointmentStatus(appointmentId, "cancelled")

    if (success) {
      return NextResponse.json({ message: "Appointment cancelled successfully" })
    } else {
      return NextResponse.json({ error: "Failed to cancel appointment" }, { status: 500 })
    }
  } catch (error) {
    console.error("Database error:", error)
    return NextResponse.json({ error: "Failed to cancel appointment" }, { status: 500 })
  }
}
