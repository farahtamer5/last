import { type NextRequest, NextResponse } from "next/server"
import { getAppointmentsByPatientId, createAppointment, checkAppointmentAvailability, findDoctorById } from "@/lib/data"

// Helper function to get user from token
function getUserFromToken(request: NextRequest) {
  const token = request.cookies.get("medibook_token")?.value

  if (!token) return null

  if (token === "demo-token") {
    return { id: "demo-patient-1", email: "patient@demo.com", role: "patient" }
  }

  if (token.startsWith("user-")) {
    const userId = token.replace("user-", "")
    return { id: userId, email: "", role: "patient" }
  }

  return null
}

export async function GET(request: NextRequest) {
  try {
    const user = getUserFromToken(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const appointments = getAppointmentsByPatientId(user.id)

    // Format appointments with doctor information
    const formattedAppointments = appointments.map((appointment) => {
      const doctor = findDoctorById(appointment.doctorId)
      return {
        id: appointment.id,
        appointment_date: appointment.appointmentDate,
        appointment_time: appointment.appointmentTime,
        status: appointment.status,
        symptoms: appointment.symptoms,
        diagnosis: appointment.diagnosis,
        prescription: appointment.prescription,
        notes: appointment.notes,
        created_at: appointment.createdAt,
        doctor_name: doctor?.name || "Unknown Doctor",
        specialization: doctor?.specialization || "General",
        consultation_fee: doctor?.consultationFee || 0,
      }
    })

    return NextResponse.json(formattedAppointments)
  } catch (error) {
    console.error("Database error:", error)
    return NextResponse.json({ error: "Failed to fetch appointments" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = getUserFromToken(request)
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { doctor_id, appointment_date, appointment_time, symptoms } = await request.json()

    if (!doctor_id || !appointment_date || !appointment_time || !symptoms) {
      return NextResponse.json({ error: "All fields are required" }, { status: 400 })
    }

    // Validate appointment date
    const appointmentDate = new Date(appointment_date)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    if (appointmentDate < today) {
      return NextResponse.json({ error: "Appointment date cannot be in the past" }, { status: 400 })
    }

    // Check availability
    const isAvailable = checkAppointmentAvailability(doctor_id, appointment_date, appointment_time)
    if (!isAvailable) {
      return NextResponse.json({ error: "This time slot is already booked" }, { status: 400 })
    }

    // Create appointment
    const newAppointment = createAppointment({
      patientId: user.id,
      doctorId: doctor_id,
      appointmentDate: appointment_date,
      appointmentTime: appointment_time,
      symptoms: symptoms.trim(),
      status: "scheduled",
    })

    return NextResponse.json({
      message: "Appointment booked successfully",
      appointmentId: newAppointment.id,
    })
  } catch (error) {
    console.error("Database error:", error)
    return NextResponse.json({ error: "Failed to book appointment" }, { status: 500 })
  }
}
