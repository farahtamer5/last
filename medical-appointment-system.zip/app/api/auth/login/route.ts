import { type NextRequest, NextResponse } from "next/server"
import { findUserByEmail } from "@/lib/data"

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    // Handle demo login
    if (email === "patient@demo.com" && password === "password123") {
      const demoUser = {
        id: "demo-patient-1",
        name: "Demo Patient",
        email: "patient@demo.com",
        password: "password123",
        phone: "555-0123",
        role: "patient" as const,
        createdAt: new Date(),
      }

      const response = NextResponse.json({
        message: "Login successful",
        user: {
          id: demoUser.id,
          name: demoUser.name,
          email: demoUser.email,
          role: demoUser.role,
        },
      })

      // Set HTTP-only cookie
      response.cookies.set("medibook_token", "demo-token", {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      })

      return response
    }

    // Check existing users
    const user = findUserByEmail(email)
    if (!user || user.password !== password) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    const response = NextResponse.json({
      message: "Login successful",
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    })

    // Set HTTP-only cookie
    response.cookies.set("medibook_token", `user-${user.id}`, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    })

    return response
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Login failed" }, { status: 500 })
  }
}
