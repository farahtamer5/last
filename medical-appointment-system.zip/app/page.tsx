"use client"

import Link from "next/link"
import { Calendar, Clock, Users, Shield, Star } from "lucide-react"
import LayoutWrapper from "@/components/layout-wrapper"

export default function HomePage() {
  return (
    <LayoutWrapper>
      {/* Hero Section */}
      <section className="hero-section text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Book Your Medical Appointments
            <span className="text-yellow-300"> Online</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto opacity-90">
            Connect with qualified doctors, schedule appointments at your convenience, and manage your healthcare
            journey all in one place.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/register" className="btn btn-primary btn-lg">
              Get Started
            </Link>
            <Link
              href="/login"
              className="btn btn-outline-primary btn-lg bg-white/10 border-white text-white hover:bg-white hover:text-blue-600"
            >
              Patient Login
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center text-gray-800 mb-16">Why Choose MediBook?</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="card feature-card text-center">
              <div className="card-body">
                <Calendar className="w-16 h-16 text-blue-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-3">Easy Scheduling</h3>
                <p className="text-gray-600">Book appointments with your preferred doctors in just a few clicks</p>
              </div>
            </div>

            <div className="card feature-card text-center">
              <div className="card-body">
                <Clock className="w-16 h-16 text-green-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-3">24/7 Access</h3>
                <p className="text-gray-600">Schedule appointments anytime, anywhere with our online platform</p>
              </div>
            </div>

            <div className="card feature-card text-center">
              <div className="card-body">
                <Users className="w-16 h-16 text-purple-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-3">Qualified Doctors</h3>
                <p className="text-gray-600">Access to a network of experienced and certified medical professionals</p>
              </div>
            </div>

            <div className="card feature-card text-center">
              <div className="card-body">
                <Shield className="w-16 h-16 text-red-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-3">Secure & Private</h3>
                <p className="text-gray-600">Your medical information is protected with enterprise-grade security</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div className="card stat-card">
              <div className="card-body">
                <div className="text-4xl font-bold text-blue-600 mb-2">8+</div>
                <div className="text-xl font-semibold text-gray-800 mb-2">Specialist Doctors</div>
                <div className="text-gray-600">Across multiple specializations</div>
              </div>
            </div>

            <div className="card stat-card">
              <div className="card-body">
                <div className="text-4xl font-bold text-green-600 mb-2">24/7</div>
                <div className="text-xl font-semibold text-gray-800 mb-2">Online Booking</div>
                <div className="text-gray-600">Book appointments anytime</div>
              </div>
            </div>

            <div className="card stat-card">
              <div className="card-body">
                <div className="text-4xl font-bold text-purple-600 mb-2">100%</div>
                <div className="text-xl font-semibold text-gray-800 mb-2">Secure Platform</div>
                <div className="text-gray-600">Your data is always protected</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Specializations Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center text-gray-800 mb-16">Our Medical Specializations</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              "Cardiology",
              "Dermatology",
              "Orthopedics",
              "Pediatrics",
              "Neurology",
              "Gynecology",
              "Psychiatry",
              "Ophthalmology",
            ].map((specialization) => (
              <div key={specialization} className="card feature-card">
                <div className="card-body text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Star className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-gray-800">{specialization}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center text-gray-800 mb-16">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-white">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Create Account</h3>
              <p className="text-gray-600">Sign up with your basic information and verify your account</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-white">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Choose Doctor</h3>
              <p className="text-gray-600">Browse our qualified doctors and select based on specialization</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-white">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Book Appointment</h3>
              <p className="text-gray-600">Select your preferred date and time, then confirm your appointment</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of patients who trust MediBook for their healthcare needs
          </p>
          <Link href="/register" className="btn btn-lg bg-white text-blue-600 hover:bg-gray-100">
            Create Your Account
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold">M</span>
                </div>
                <span className="text-xl font-bold">MediBook</span>
              </div>
              <p className="text-gray-400">Your trusted partner for online medical appointment booking.</p>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/login" className="hover:text-white">
                    Login
                  </Link>
                </li>
                <li>
                  <Link href="/register" className="hover:text-white">
                    Register
                  </Link>
                </li>
                <li>
                  <Link href="/" className="hover:text-white">
                    Find Doctors
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Specializations</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Cardiology</li>
                <li>Dermatology</li>
                <li>Pediatrics</li>
                <li>Neurology</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <ul className="space-y-2 text-gray-400">
                <li>📧 support@medibook.com</li>
                <li>📞 1-800-MEDIBOOK</li>
                <li>🏥 Available 24/7</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 MediBook. All rights reserved. | Built for Academic Project</p>
          </div>
        </div>
      </footer>
    </LayoutWrapper>
  )
}
