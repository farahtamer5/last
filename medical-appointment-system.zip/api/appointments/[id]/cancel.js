const jwt = require("jsonwebtoken")
const clientPromise = require("../../../lib/mongodb")
const Appointment = require("../../../models/Appointment")

// Authentication helper
function authenticateToken(req) {
  const cookies = req.headers.cookie
  if (!cookies) return null

  const tokenCookie = cookies.split(";").find((c) => c.trim().startsWith("token="))
  if (!tokenCookie) return null

  const token = tokenCookie.split("=")[1]
  try {
    return jwt.verify(token, process.env.JWT_SECRET || "fallback-secret")
  } catch {
    return null
  }
}

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader("Access-Control-Allow-Credentials", true)
  res.setHeader("Access-Control-Allow-Origin", process.env.CORS_ORIGIN || "*")
  res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS,PATCH,DELETE,POST,PUT")

  if (req.method === "OPTIONS") {
    res.status(200).end()
    return
  }

  if (req.method !== "PATCH") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  // Authenticate user
  const user = authenticateToken(req)
  if (!user) {
    return res.status(401).json({ error: "Unauthorized" })
  }

  try {
    const { id } = req.query

    // Connect to MongoDB
    const client = await clientPromise
    const db = client.db("medical_booking")
    const appointmentModel = new Appointment(db)

    // Cancel the appointment
    const result = await appointmentModel.cancelById(id, user.userId)

    if (result.matchedCount === 0) {
      return res.status(404).json({ error: "Appointment not found or cannot be cancelled" })
    }

    res.status(200).json({ message: "Appointment cancelled successfully" })
  } catch (error) {
    console.error("Database error:", error)
    res.status(500).json({ error: "Failed to cancel appointment" })
  }
}
