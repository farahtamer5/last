const clientPromise = require("../lib/mongodb")
const Doctor = require("../models/Doctor")

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader("Access-Control-Allow-Credentials", true)
  res.setHeader("Access-Control-Allow-Origin", process.env.CORS_ORIGIN || "*")
  res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS,PATCH,DELETE,POST,PUT")

  if (req.method === "OPTIONS") {
    res.status(200).end()
    return
  }

  if (req.method !== "GET") {
    return res.status(405).json({ error: "Method not allowed" })
  }

  try {
    // Connect to MongoDB
    const client = await clientPromise
    const db = client.db("medical_booking")
    const doctorModel = new Doctor(db)

    // Get all doctors
    const doctors = await doctorModel.findAll()

    res.status(200).json(doctors)
  } catch (error) {
    console.error("Database error:", error)
    res.status(500).json({ error: "Failed to fetch doctors" })
  }
}
