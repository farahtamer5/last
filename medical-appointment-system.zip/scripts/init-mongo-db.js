const { MongoClient } = require("mongodb")
require("dotenv").config()

const uri = process.env.MONGODB_URI
const dbName = "medical_booking"

async function initializeMongoDB() {
  console.log("🏥 Initializing Medical Appointment Booking Database (MongoDB)...")
  console.log("================================================================")

  if (!uri) {
    console.error("❌ MONGODB_URI environment variable is not set")
    process.exit(1)
  }

  let client
  try {
    client = new MongoClient(uri)
    await client.connect()
    console.log("✅ Connected to MongoDB")

    const db = client.db(dbName)

    // Create collections and indexes
    console.log("📋 Creating collections and indexes...")

    // Users collection
    const usersCollection = db.collection("users")
    await usersCollection.createIndex({ email: 1 }, { unique: true })
    await usersCollection.createIndex({ role: 1 })
    await usersCollection.createIndex({ createdAt: 1 })

    // Doctors collection
    const doctorsCollection = db.collection("doctors")
    await doctorsCollection.createIndex({ email: 1 }, { unique: true })
    await doctorsCollection.createIndex({ specialization: 1 })
    await doctorsCollection.createIndex({ name: 1 })

    // Appointments collection
    const appointmentsCollection = db.collection("appointments")
    await appointmentsCollection.createIndex({ patientId: 1 })
    await appointmentsCollection.createIndex({ doctorId: 1 })
    await appointmentsCollection.createIndex({ appointmentDate: 1 })
    await appointmentsCollection.createIndex({ status: 1 })
    await appointmentsCollection.createIndex({ createdAt: 1 })
    // Compound index for checking availability
    await appointmentsCollection.createIndex(
      { doctorId: 1, appointmentDate: 1, appointmentTime: 1 },
      { unique: true, partialFilterExpression: { status: { $ne: "cancelled" } } },
    )

    console.log("✅ Collections and indexes created successfully")

    // Check if doctors exist
    const doctorCount = await doctorsCollection.countDocuments()
    if (doctorCount === 0) {
      console.log("👨‍⚕️ Seeding doctors data...")

      const doctors = [
        {
          name: "John Smith",
          specialization: "Cardiology",
          email: "john.smith@hospital.com",
          phone: "123-456-7890",
          availableDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
          availableHours: "09:00-17:00",
          consultationFee: 150.0,
          experienceYears: 15,
          qualification: "MD, FACC - Harvard Medical School",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: "Sarah Johnson",
          specialization: "Dermatology",
          email: "sarah.johnson@hospital.com",
          phone: "123-456-7891",
          availableDays: ["Monday", "Wednesday", "Friday"],
          availableHours: "10:00-16:00",
          consultationFee: 120.0,
          experienceYears: 12,
          qualification: "MD, Dermatology - Johns Hopkins University",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: "Michael Brown",
          specialization: "Orthopedics",
          email: "michael.brown@hospital.com",
          phone: "123-456-7892",
          availableDays: ["Tuesday", "Thursday", "Saturday"],
          availableHours: "08:00-14:00",
          consultationFee: 180.0,
          experienceYears: 18,
          qualification: "MD, Orthopedic Surgery - Mayo Clinic",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: "Emily Davis",
          specialization: "Pediatrics",
          email: "emily.davis@hospital.com",
          phone: "123-456-7893",
          availableDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
          availableHours: "09:00-17:00",
          consultationFee: 100.0,
          experienceYears: 10,
          qualification: "MD, Pediatrics - Stanford University",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: "Robert Wilson",
          specialization: "Neurology",
          email: "robert.wilson@hospital.com",
          phone: "123-456-7894",
          availableDays: ["Monday", "Wednesday", "Friday"],
          availableHours: "11:00-18:00",
          consultationFee: 200.0,
          experienceYears: 20,
          qualification: "MD, PhD, Neurology - UCLA Medical Center",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: "Lisa Anderson",
          specialization: "Gynecology",
          email: "lisa.anderson@hospital.com",
          phone: "123-456-7895",
          availableDays: ["Tuesday", "Thursday", "Friday"],
          availableHours: "09:00-15:00",
          consultationFee: 140.0,
          experienceYears: 14,
          qualification: "MD, OB/GYN - Columbia University",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: "David Martinez",
          specialization: "Psychiatry",
          email: "david.martinez@hospital.com",
          phone: "123-456-7896",
          availableDays: ["Monday", "Tuesday", "Wednesday", "Thursday"],
          availableHours: "10:00-18:00",
          consultationFee: 160.0,
          experienceYears: 16,
          qualification: "MD, Psychiatry - Yale School of Medicine",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: "Jennifer Lee",
          specialization: "Ophthalmology",
          email: "jennifer.lee@hospital.com",
          phone: "123-456-7897",
          availableDays: ["Monday", "Wednesday", "Friday", "Saturday"],
          availableHours: "08:00-16:00",
          consultationFee: 130.0,
          experienceYears: 11,
          qualification: "MD, Ophthalmology - University of Pennsylvania",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ]

      await doctorsCollection.insertMany(doctors)
      console.log("✅ Doctors data seeded successfully")
    } else {
      console.log("ℹ️  Doctors data already exists")
    }

    console.log("🎉 Database initialization completed successfully!")
    console.log("📊 Database Statistics:")

    const userCount = await db.collection("users").countDocuments()
    const finalDoctorCount = await db.collection("doctors").countDocuments()
    const appointmentCount = await db.collection("appointments").countDocuments()

    console.log(`   Users: ${userCount}`)
    console.log(`   Doctors: ${finalDoctorCount}`)
    console.log(`   Appointments: ${appointmentCount}`)
  } catch (error) {
    console.error("❌ Database initialization failed:", error)
    throw error
  } finally {
    if (client) {
      await client.close()
      console.log("🔌 Database connection closed")
    }
  }
}

// Run if called directly
if (require.main === module) {
  initializeMongoDB()
    .then(() => {
      console.log("✅ Script completed successfully")
      process.exit(0)
    })
    .catch((error) => {
      console.error("❌ Script failed:", error)
      process.exit(1)
    })
}

module.exports = { initializeMongoDB }
